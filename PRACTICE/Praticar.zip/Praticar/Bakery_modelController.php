<?php

namespace App\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Doctrine\DBAL\Driver\Connection;

class Bakery_modelController extends AbstractController
{
	private $connection;	
	public function __construct(Connection $connection)
    {
        $this->connection = $connection;
    }

    public function get_products($id = false)
    {
        if($id){
            $products_query  = "SELECT * FROM products WHERE id = '$id'";
            $stmt = $this->connection->prepare($products_query);
            $stmt->execute();
            return $stmt->fetch();
        }
        $products_query  = "SELECT * FROM products";
        return $this->connection->fetchAll($products_query);
    }

    public function get_categories(){
        $sql = "SELECT *
        FROM categories";
        $categories = $this->connection->fetchAll($sql);
        return $categories;
    }

    public function get_products_by_category($cat_id){
        $products_query  = "SELECT * FROM products WHERE cat_id = '$cat_id'";
        return $this->connection->fetchAll($products_query);
    }

    public function get_user($id){
        $sql = "SELECT * FROM users WHERE id = '$id'";
        $stmt = $this->connection->prepare($sql);   
        $stmt->execute();           
        return $stmt->fetch();
    }

    public function get_email($email){
        $sql = "SELECT * FROM users WHERE email = '$email'";
        $stmt = $this->connection->prepare($sql);   
        $stmt->execute();           
        return $stmt->fetch();
    }


    public function register_user($username,$email,$password){
        $sql = "INSERT INTO users (name, email, created_at, updated_at, password_digest) VALUES ('" . $username . "','" . $email . "', NOW(), NOW(),'" . substr(md5($password),0,32) . "')";
        $stmt = $this->connection->prepare($sql);
        $stmt->execute();   
        return true;
    }

    public function login_user($email, $password)
    { 
        $sql = "SELECT * FROM users WHERE email='" . $email . "' AND password_digest='" . substr(md5($password),0,32) . "'";
        $stmt = $this->connection->prepare($sql);   
        $stmt->execute();           
        return $stmt->fetch();
    }

    public function set_remember_digest($email,$remember_digest)
    {
        $sql = "UPDATE users SET remember_digest='$remember_digest'  WHERE email='$email'";
        $stmt = $this->connection->prepare($sql);
        $stmt->execute();   
        return true;
    }

    public function check_remember_digest($remember_digest)
    {
        $sql = "SELECT * FROM users WHERE remember_digest = '$remember_digest'";
        $stmt = $this->connection->prepare($sql);   
        $stmt->execute();           
        return $stmt->fetch();
    }

    public function create_order($product_id, $userid, $total)
    {
        $sql = "INSERT INTO orders (user_id, created_at, status, total)
            VALUES ('$userid', NOW(), 0, '$total')";
        $stmt = $this->connection->prepare($sql);
        $create_order = $stmt->execute();   
        if ($create_order == false)
            return false;
        $insert_id = $this->connection->lastInsertId();
        return $this->create_order_item($insert_id, $product_id);

    }

    public function create_order_item($order_id, $product_id)
    {
        $sql = "INSERT INTO order_items (order_id, product_id, quantity)
            VALUES ('$order_id', '$product_id', 1)"; 
        $stmt = $this->connection->prepare($sql);
        return $stmt->execute(); 
    }

    public function get_orders($user_id){
        $query = "SELECT * FROM orders WHERE user_id = '$user_id'";
        return $this->connection->fetchAll($query);
    }

    public function get_order_item($order_id){
        $query = "SELECT * FROM order_items 
            WHERE order_items.order_id = '$order_id' ";
        return $this->connection->fetchAll($query);
    }

    


}

?>