<?php

namespace App\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\HttpFoundation\Session\SessionInterface;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\PropertyAccess\PropertyAccess;
use Symfony\Component\Validator\Constraints as Assert;
use Symfony\Component\Validator\Validator\ValidatorInterface;
use Symfony\Component\Validator\Context\ExecutionContextInterface;
use App\Controller\Bakery_modelController;

class BakeryController extends AbstractController{
    private $bakery_model;
    private $session;
    private $validator;
    public function __construct(Bakery_modelController $bakery_model, SessionInterface $session, ValidatorInterface $validator){
        $this->bakery_model = $bakery_model;
        $this->session = $session;
        $this->validator = $validator;
    }


        /**
         * @Route("/bakery", name="bakery")
         */
        public function index(): Response
        {
            $data['userid'] = $this->session->get('userid');

            if($this->session->get('userid')){
                $data['name'] = $this->bakery_model->get_user($this->session->get('userid'));
                return $this->render('bakery/home.html.twig', $data);
            }
            return $this->render('bakery/home.html.twig', $data);
        }

         /**
        * @Route("/menu/{cat_id?}", name="menu")
        */
        public function menu($cat_id = false)
        {
            
            $data['categories'] = $this->bakery_model->get_categories(); 
            if($this->session->get('userid')){
                $data['name'] = $this->bakery_model->get_user($this->session->get('userid'));
                if($cat_id){
                    $data['cat_id'] = $cat_id;
                    $data['products'] = $this->bakery_model->get_products_by_category($cat_id);
                }else{
                    $data['cat_id'] = false;
                    $data['products'] = $this->bakery_model->get_products();
                }
            }else{
                if($cat_id){
                    $data['cat_id'] = $cat_id;
                    $data['products'] = $this->bakery_model->get_products_by_category($cat_id);
                }else{
                    $data['cat_id'] = false;
                    $data['products'] = $this->bakery_model->get_products();
                }
            }
            return $this->render('bakery/menu.html.twig', $data);
        }

        /**
        * @Route("/register", name="register")
        */
        public function register(){
      
            if ($this->session->get('errors') > 0)
            {
                $data['errors'] = $this->session->get('errors');
                $data['email'] = $this->session->get('email');
                $data['username'] = $this->session->get('username');
                $data['errorMessages'] = $this->session->get('errorMessages');
            }
            else
            {
                $data['errors'] = 0;
                $data['email'] = '';
                $data['username'] = '';
                return $this->render('bakery/register.html.twig', $data);
            }
        
            return $this->render('bakery/register.html.twig', $data);

            }

        /**
        * @Route("/bakery/register_action", name="register_action")
        */
        public function register_action(Request $request, ValidatorInterface $validator){
            
            $token = $request->request->get("token");

            if (!$this->isCsrfTokenValid('register_form', $token)) {
               return new Response("Operation not allowed", Response::HTTP_OK,
                   ['content-type' => 'text/plain']);
           }
      
      
           $username=$request->request->get('username');
           $email=$request->request->get('email');
           $password=$request->get('password');
           $passconf=$request->get('passconf');

           $user = $this->bakery_model->get_email($email);
           if ($user == false)
               $value = '';
           else{
               $value = $user['email'];
           }

            $input = ['password' => $password, 'passconf' => $passconf, 'username' => $username, 'email' => $email];

            $constraints = new Assert\Collection([
                'username' => [new Assert\NotBlank(['message' => "Your name must not be blank"])],
                'email'=>   [new Assert\NotBlank,
                                    new Assert\NotEqualTo(['value' => $value, 'message' => "This email is already registered"])],
                'password' => [new Assert\notBlank,
                                    new Assert\EqualTo(['value' => $passconf, 'message' => "Passwords do not match"])],
                'passconf' => [new Assert\notBlank(['message' => "Password Confirmation must not be blank"])],             
            ]);
    
              
            $data = $this->requestValidation($input, $constraints);

            if ( $data['errors'] > 0) {
                $this->session->set('errorMessages', $data['errorMessages']);
                $data['email'] = $email;
                $data['username'] = $username;

                return $this->render('bakery/register.html.twig', $data);
            }
            
            
            $this->bakery_model->register_user($username,$email,$password);
            return $this->redirectToRoute('login');
    }

         /**
         * @Route("/login", name="login")
         */
        public function login(){
      
            if ($this->session->get('errors') > 0)
            {
                $data['errors'] = $this->session->get('errors');
                $data['email'] = $this->session->get('email');
                $data['errorMessages'] = $this->session->get('errorMessages');
            }else
            {
                $data['errors'] = 0;
                $data['email'] = '';
                return $this->render('bakery/login.html.twig', $data);
            }
            return $this->render('bakery/login.html.twig', $data);
            }

            /**
        * @Route("/bakery/login_action", name="login_action")
        */
        public function login_action(Request $request, ValidatorInterface $validator)
        {
            $token = $request->request->get("token");

            if (!$this->isCsrfTokenValid('login_form', $token)) {
                return new Response("Operation not allowed", Response::HTTP_OK,
                   ['content-type' => 'text/plain']);
           }
      
            $email=$request->request->get('email');
            $password=$request->get('password');

            $user = $this->bakery_model->login_user($email, $password);
            if ($user == false)
                $value = '';
            else
                $value = $password;
          
            $input = ['password' => $password,  'email' => $email];

            $constraints = new Assert\Collection([
               'email' => [new Assert\NotBlank(['message' => "Email must not be blank"])],
               'password' => [new Assert\notBlank(['message' => "Password must not be blank"]),
                               new Assert\EqualTo(['value' => $value, 'message' => "Wrong email or password"])],   
                ]);


           
            $data = $this->requestValidation($input, $constraints);
            if ( $data['errors'] > 0) {
                $this->session->set('errorMessages', $data['errorMessages']);
                $data['email'] = $email;

                return $this->render('bakery/login.html.twig', $data);
            }

            $remember = $request->request->get('autologin');

            if($user == true && $remember == 1)
            {
                $cookie_name = 'siteAuth';
                $cookie_time = (time() + (60 * 24 * 30)); // 30 days
                $remember_digest = substr(md5(time()),0,32);
                $response = new Response();
                $cookie = Cookie::create($cookie_name,$remember_digest, $cookie_time);
                $response->headers->setCookie($cookie);
                $response->send(); 
                $this->bakery_model->set_remember_digest($email,$remember_digest);
      
            }

            $this->session->set('userid', $user['id']);
            $this->session->set('email', $user['email']);

            $data['userid'] = $this->session->get('userid');
            $user = $this->bakery_model->get_user($this->session->get('userid'));
            $data['message'] = 'Welcome ' . $user['name'];
            return $this->redirectToRoute('bakery');
        }
         /**
         * @Route("/logout", name="logout")
         */
        public function logout()
        {
            $this->session->set('userid', '');
            $this->session->set('username', '');
            $response = new Response();
            $cookie = Cookie::create('siteAuth',null);
            $response->headers->setCookie($cookie);
            $response->send(); 
            $this->session->clear();
            $data['message'] = 'See you back soon!';
            return $this->render('bakery/message.html.twig', $data);
        }


        private function requestValidation($input, $constraints){
      
            $violations = $this->validator->validate($input, $constraints);
       
             $errorMessages = [];
           
            if (count($violations) > 0) {
 
                $accessor = PropertyAccess::createPropertyAccessor();
 
                foreach ($violations as $violation) {
 
                    $accessor->setValue($errorMessages,
                     $violation->getPropertyPath(),
                     $violation->getMessage());
                }
           
            }   
             $data['errors'] = count($violations);
             $data['errorMessages'] = $errorMessages;
                 
             return $data;
        }

        /**
        * @Route("/order/{product_id}", name="order")
        */
        public function order($product_id):Response{

            $userid = $this->session->get('userid');
            $product = $this->bakery_model->get_products($product_id);
            if($userid){
                $order = $this->bakery_model->create_order($product_id, $userid, $product['price']);
                return $this->redirectToRoute('menu');
            }
            else{
                return Response::HTTP_UNAUTHORIZED;
            }
            
        }

        /**
        * @Route("/orders", name="orders") 
        */
        public function orders(){
            $userid = $this->session->get('userid');
            $orders = $this->bakery_model->get_orders($userid);
            foreach($orders as $o){
                $order_item = $this->bakery_model->get_order_item($o['id']);
                $product_id = $order_item[$o['id']];
                $products[$o['id']] = $this->bakery_model->get_products($product_id);
            }

            $data['products'] = $products;
            $data['orders'] = $orders;
            return $this->render('bakery/myOrders.html.twig', $data);
        }
    }
?>